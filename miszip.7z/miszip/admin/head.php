<title>admin</title>
<META NAME="description" CONTENT="test"/>
<META NAME="keywords" CONTENT="test">
<META NAME="author" CONTENT="Wiebe de Boer">
<META NAME="copyright" CONTENT="2017, Wiebe de Boer">
<META NAME="ROBOTS" CONTENT="NOINDEX,NOFOLLOW">
<meta http-equive="content-type" content="text/html; charset=UTF8">
<link rel="shortcut icon" type="image/png" href="../favicon.png">
<link rel="stylesheet" type="text/css" href="../styles/cms_style3.css">
<style>
a.bl {color:#ff0000 !important;}
a.br {color:#ff0000 !important;}
</style>
