<!DOCTYPE HTML>
<HTML>
<HEAD>
<?php
include("head.php");
?>
</HEAD>
<BODY>
<h1>Administratief</h1>
<form method="POST" action="portal.php">
<table class="inlog">
<tr><td class="inl">Gebruikersnaam: </td><td class="inl"><input type="text" size="20" maxlength="45" name="username" /></td></tr>
<tr><td class="inl">Wachtwoord: </td><td class="inl"><input type="password" size="20" maxlength="20" name="password" /></td></tr>
<tr><td class="inl">&nbsp;</td><td class="inl"><input type="submit" value="login" /></td></tr>
</table>
</form>

</BODY>
</HTML>
