<?php

echo '
<button class="socm"><img src="resources/facebook.png"/></button>
<button class="socm"><img src="resources/twitter.png"/></button>
<button class="socm"><img src="resources/instagram.png"/></button>
';

/*
echo '

<a href="https://www.instagram.com/" class="menu_link">Instagram</a>

<a href="mailto:info@recentnieuws.nl" class="menu_link">E-mail</a>

<a href="https://www.facebook.com/" class="menu_link">Facebook</a>

<a href="https://twitter.com/" class="menu_link">Twitter</a>

';

*/

?>


