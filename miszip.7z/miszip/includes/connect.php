<?php

//DATABASE CONNECTION VARIABLES
$myserver ="localhost";
$myname = "geennaam";
$mypassword = "watte2017";
$mydb = "test_nl";

?>
